package android.example.com

data class MyName(var name: String = "", var nickname: String = "")